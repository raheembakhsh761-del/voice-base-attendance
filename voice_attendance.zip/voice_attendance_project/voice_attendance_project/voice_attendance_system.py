import os
import numpy as np
import librosa
import sounddevice as sd
import scipy.io.wavfile as wav
from sklearn.metrics.pairwise import cosine_similarity
from openpyxl import Workbook
from datetime import datetime
import time

ENROLL_DIR = "enrolled_voices"
LECTURE_DIR = "lectures"
ATTENDANCE_DURATION = 120  # seconds

def record_voice(filename="temp.wav", duration=4, fs=16000):
    print(f"Recording for {duration} seconds...")
    recording = sd.rec(int(duration * fs), samplerate=fs, channels=1)
    sd.wait()
    wav.write(filename, fs, recording)
    print("Recording complete.")

def extract_features(filepath):
    y, sr = librosa.load(filepath, sr=16000)
    mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13)
    return np.mean(mfcc.T, axis=0)

def enroll_student(name):
    if not os.path.exists(ENROLL_DIR):
        os.makedirs(ENROLL_DIR)
    filename = "temp.wav"
    record_voice(filename)
    features = extract_features(filename)
    np.save(os.path.join(ENROLL_DIR, f"{name}.npy"), features)
    os.remove(filename)
    print(f"{name} enrolled successfully.\n")

def match_voice(test_feat):
    max_score = 0
    matched_name = None
    for fname in os.listdir(ENROLL_DIR):
        enrolled_feat = np.load(os.path.join(ENROLL_DIR, fname))
        score = cosine_similarity([test_feat], [enrolled_feat])[0][0]
        if score > max_score:
            max_score = score
            matched_name = fname.replace(".npy", "")
    if max_score >= 0.85:
        return matched_name
    return None

def take_attendance(duration=ATTENDANCE_DURATION):
    lecture_name = input("Enter Lecture Name (e.g., Lecture1): ").strip()
    lecture_title = input("Enter Lecture Title (e.g., Introduction to AI): ").strip()
    lecture_place = input("Enter Lecture Place (e.g., Room 101): ").strip()
    timestamp = datetime.now().strftime("%Y-%m-%d_%I-%M-%p")
    readable_date = datetime.now().strftime("%Y-%m-%d")

    if not os.path.exists(LECTURE_DIR):
        os.makedirs(LECTURE_DIR)

    excel_filename = f"{lecture_name}_{timestamp}.xlsx"
    excel_filepath = os.path.join(LECTURE_DIR, excel_filename)

    print(f"\n[Attendance Mode] Listening for {duration} seconds...\n")
    start_time = time.time()
    present_students = set()
    all_students = [f.replace(".npy", "") for f in os.listdir(ENROLL_DIR)]

    while time.time() - start_time < duration:
        filename = "temp.wav"
        record_voice(filename, duration=3)
        feat = extract_features(filename)
        match = match_voice(feat)
        os.remove(filename)

        if match and match not in [p[0] for p in present_students]:
            now = datetime.now()
            time_str = now.strftime("%I:%M:%S %p")
            print(f"[✔] {match} is Present at {time_str}")
            present_students.add((match, time_str))

    print("\n[✓] Attendance session complete.")

    # Find absent students
    absent_students = [name for name in all_students if name not in [p[0] for p in present_students]]

    # Write to Excel with exact format
    wb = Workbook()
    ws = wb.active
    ws.title = "Attendance"

    # Metadata (rows 1-4)
    ws.append(["Lecture Name", lecture_name])
    ws.append(["Lecture Title", lecture_title])
    ws.append(["Lecture Place", lecture_place])
    ws.append(["Date", readable_date])

    # Empty row (row 5)
    ws.append([])

    # Table header (row 6)
    ws.append(["Name", "Status", "Time"])

    # Add present students
    for name, time_str in present_students:
        ws.append([name, "Present", time_str])

    # Add absent students
    for name in absent_students:
        ws.append([name, "Absent", ""])

    # Save file
    wb.save(excel_filepath)
    print(f"[📁] Attendance saved to: {excel_filepath}")

def view_enrollments():
    print("\n--- Enrolled Students ---")
    if not os.path.exists(ENROLL_DIR):
        print("No students enrolled yet.")
        return
    for fname in os.listdir(ENROLL_DIR):
        if fname.endswith(".npy"):
            print(fname.replace(".npy", ""))
    print("-------------------------")

def main():
    while True:
        print("\n=== Voice Attendance System ===")
        print("1. Enroll new student")
        print("2. Take lecture attendance")
        print("3. View enrolled students")
        print("4. Exit")
        choice = input("Select an option (1-4): ")

        if choice == "1":
            while True:
                name = input("Enter student name to enroll: ").strip()
                enroll_student(name)
                more = input("Enroll another student? (y/n): ").strip().lower()
                if more != 'y':
                    break
        elif choice == "2":
            take_attendance()
        elif choice == "3":
            view_enrollments()
        elif choice == "4":
            print("Exiting system.")
            break
        else:
            print("Invalid choice. Try again.")

if __name__ == "__main__":
    main()
